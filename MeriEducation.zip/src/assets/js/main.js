jQuery(document).ready(function(){
	jQuery('#select-center , #select-tutors').selectize({
	  maxItems: 3,
	  plugins: ['remove_button']
	});
	jQuery('#select-time').selectize();
  jQuery("input[name='optradio']").change(function() {
      jQuery(".input-daterange").hide();
      jQuery("#" + $(this).data("for")).show();
  });
	jQuery('.input-daterange input').each(function() {
	    $(this).datepicker('clearDates');
	});
  jQuery("body").delegate("body", "load", function() {
    jQuery( ".banner__tutors .option" ).append( "<div class='teacher__profile'><div class='teacher__profile__top'><figure><img src='img/tutor.jpg' alt='Teacher'><figcaption><ul><li><i class='fa fa-star'></i></li><li><i class='fa fa-star'></i></li><li><i class='fa fa-star'></i></li><li><i class='fa fa-star'></i></li><li><i class='fa fa-star-half'></i></li></ul></figcaption></figure><ul><li><a href='#'>Math,</a></li><li><a href='#'>English,</a></li><li><a href='#'>Calculus,</a></li><li><a href='#'>Economics,</a></li><li><a href='#'>Geometry,</a></li><li><a href='#'>Statics,</a></li><li><a href='#'>SAT Math</a></li></ul></div><p>Lorem ipsum dolor sit amet,  animi consectetur adipisicing elit. Eligendi</p><div class='teacher__profile__bottom'><p>Joseph Y.</p><a href='#'><i class='fa fa-hand-o-right'></i> See Bio</a></div></div>" );
  });
});

/* Typeahead */
var substringMatcher = function(strs) {
  return function findMatches(q, cb) {
    var matches, substringRegex;

    // an array that will be populated with substring matches
    matches = [];

    // regex used to determine if a string contains the substring `q`
    substrRegex = new RegExp(q, 'i');

    // iterate through the pool of strings and for any string that
    // contains the substring `q`, add it to the `matches` array
    $.each(strs, function(i, str) {
      if (substrRegex.test(str)) {
        matches.push(str);
      }
    });

    cb(matches);
  };
};

var states = ['Alabama', 'Alaska', 'Arizona', 'Arkansas', 'California',
  'Colorado', 'Connecticut', 'Delaware', 'Florida', 'Georgia', 'Hawaii',
  'Idaho', 'Illinois', 'Indiana', 'Iowa', 'Kansas', 'Kentucky', 'Louisiana',
  'Maine', 'Maryland', 'Massachusetts', 'Michigan', 'Minnesota',
  'Mississippi', 'Missouri', 'Montana', 'Nebraska', 'Nevada', 'New Hampshire',
  'New Jersey', 'New Mexico', 'New York', 'North Carolina', 'North Dakota',
  'Ohio', 'Oklahoma', 'Oregon', 'Pennsylvania', 'Rhode Island',
  'South Carolina', 'South Dakota', 'Tennessee', 'Texas', 'Utah', 'Vermont',
  'Virginia', 'Washington', 'West Virginia', 'Wisconsin', 'Wyoming'
];

$('#the-basics .typeahead').typeahead({
  hint: true,
  highlight: true,
  minLength: 1
},
{
  name: 'states',
  source: substringMatcher(states)
});